*PADS-LIBRARY-PART-TYPES-V9*

031-5329-51RFX 031532951RFX I CON 7 1 0 0 0
TIMESTAMP 2026.11.23.12.49.44
"Mouser Part Number" 523-31-5329-51RFX
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Amphenol-RF/031-5329-51RFX?qs=py4qCovljJ9v8K3Z%252BReCzQ%3D%3D
"Manufacturer_Name" Amphenol
"Manufacturer_Part_Number" 031-5329-51RFX
"Description" BNC Straight PCB Jack Through Hole 50 Ohm
"Datasheet Link" https://s3-us-west-2.amazonaws.com/catsy.582/C31-5329-51RFX.pdf
"Geometry.Height" 16.764mm
GATE 1 5 0
031-5329-51RFX
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5

*END*
*REMARK* SamacSys ECAD Model
1799690/2235147/2.50/5/3/Connector
